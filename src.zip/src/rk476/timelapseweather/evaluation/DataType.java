package rk476.timelapseweather.evaluation;

public enum DataType {
    DISCRETE,
    CONTINUOUS,
    TIME
}
